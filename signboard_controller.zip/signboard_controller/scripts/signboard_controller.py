#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import threading
import rospy

from std_msgs.msg import Int32

# 기존 워크스페이스의 메시지 타입을 그대로 사용한다고 가정
from chassis_controller_w_cam.msg import SetVelocity, DetectArrayMsg


class SignboardController:
    def __init__(self):
        # -------------------------
        # Params
        # -------------------------
        self.image_center_u = rospy.get_param("~image_center_u", 320)

        self.scan_deg_limit = rospy.get_param("~scan_deg_limit", 15.0)       # ±20deg
        self.scan_step_deg  = rospy.get_param("~scan_step_deg", 5.0)         # 스캔 간격
        self.scan_wait_sec  = rospy.get_param("~scan_wait_sec", 0.5)         # 회전 후 detection 기다리는 시간

        # 간단 P 제어 gain (원하는대로 튜닝)
        self.kp_center = rospy.get_param("~kp_center", 0.05)                 # pixel -> deg 변환용 gain (대충 값)
        self.center_tol_px = rospy.get_param("~center_tol_px", 5)            # 허용 오차

        # -------------------------
        # State
        # -------------------------
        self._lock = threading.Lock()
        self._latest_dets = []  # DetectMsg list
        self._latest_stamp = rospy.Time(0)

        # -------------------------
        # Pub/Sub
        # -------------------------
        self.vel_pub = rospy.Publisher("/chassis_control/set_velocity", SetVelocity, queue_size=10)
        self.center_done_pub = rospy.Publisher("/center_alignment_complished", Int32, queue_size=1, latch=False)

        self.signboard_sub = rospy.Subscriber("/signboard", Int32, self.signboard_cb, queue_size=10)
        self.yolo_sub = rospy.Subscriber("/yolo/center", DetectArrayMsg, self.yolo_cb, queue_size=10)

        # -------------------------
        # Start-up behavior
        # -------------------------
        # 노드 시작 후 바로 orientation_align 실행 (짧게 지연 줘서 토픽 연결 안정화)
        rospy.Timer(rospy.Duration(0.5), self._oneshot_startup, oneshot=True)

    # =========================
    # Callbacks
    # =========================
    def signboard_cb(self, msg: Int32):
        # TODO: 내용은 필요없다고 해서 비워둠
        val=0
        x=1
        
        self.height_align(temp=val%1000)
        self.fmove_by_dis_m(x)
        if val%1000 ==11:
            self.rotate_by_deg(-90)
            self.fmove_by_dis_m(x)
            if(val>1000):
                self.rotate_by_deg(-90)
        elif val%1000==12:
            self.rotate_by_deg(90)
            self.fmove_by_dis_m(x)
            if(val>1000):
                self.rotate_by_deg(90)



        pass

    def yolo_cb(self, msg: DetectArrayMsg):
        with self._lock:
            self._latest_dets = list(msg.detections)
            self._latest_stamp = rospy.Time.now()

    # =========================
    # Helpers: detection picking
    # =========================
    def _pick_target_signboard(self, dets):
        """
        id 15~17 중 감지된 객체들만 필터링 후,
        그 중 id가 가장 작은(det.id 최소) 것을 선택.
        """
        
        candidates = [d for d in dets if 11 <= int(d.id) <= 13]
        if not candidates:
            return None
        candidates.sort(key=lambda d: int(d.id))
        return candidates[0]

    def _bbox_area(self, det) -> int:
        w = abs(int(det.x2) - int(det.x1))
        h = abs(int(det.y2) - int(det.y1))
        return w * h

    # =========================
    # Motion primitives
    # =========================
    def rotate_by_deg(self, deg: float):
        """
        deg 만큼 회전시키는 함수.
        여기서는 SetVelocity 메시지를 사용하고, angular에 deg를 '명령값'으로 넣는 형태로 뼈대만 둠.
        (실제 로봇 컨트롤 규약에 맞게 direction/velocity/angular 의미를 맞춰 수정 필요)
        """
        vel = SetVelocity()
        vel.velocity = 0.0
        vel.direction = 0
        vel.angular = float(deg)
        self.vel_pub.publish(vel)

    def fmove_by_dis_m(self, dis_m: float):
        """
        dis_m 만큼 이동시키는 함수.
        여기서는 velocity/direction에 단순히 넣는 뼈대만 둠.
        """
        vel = SetVelocity()
        vel.velocity = float(dis_m)   # 실제로는 속도/거리 분리 필요할 수 있음
        vel.direction = 90            # 예: 전진(규약에 맞춰 수정)
        vel.angular = 0.0
        self.vel_pub.publish(vel)
    
    def rmove_by_dis_m(self, dis_m: float):
        """
        dis_m 만큼 이동시키는 함수.
        여기서는 velocity/direction에 단순히 넣는 뼈대만 둠.
        """
        vel = SetVelocity()
        vel.velocity = float(dis_m)   # 실제로는 속도/거리 분리 필요할 수 있음
        vel.direction = 180            # 예: 전진(규약에 맞춰 수정)
        vel.angular = 0.0
        self.vel_pub.publish(vel)

    def stop(self):
        vel = SetVelocity()
        vel.velocity = 0.0
        vel.direction = 0
        vel.angular = 0.0
        self.vel_pub.publish(vel)

    # =========================
    # Main behaviors
    # =========================
    def _oneshot_startup(self, _evt):
        # 시작 시 orientation align 수행
        try:
            self.orientation_align()
        except Exception as e:
            rospy.logerr(f"[orientation_align] exception: {e}")

    def orientation_align(self):
        """
        (void 타입) 시스템 시작하면
        /yolo/center 로 들어온 signboard bbox "크기"를 최소화하는 각도를 탐색하고,
        그 최소각으로 실제 이동(회전)까지 수행.
        - id 15~17 중 det된 것들 중 id 최소 사용
        - ±20deg 정도를 스캔
        """
        rospy.loginfo("[orientation_align] start")

        # 스캔 각 리스트: -20, -15, ..., 0, ..., +20
        angles = []
        a = -self.scan_deg_limit
        while a <= self.scan_deg_limit + 1e-9:
            angles.append(a)
            a += self.scan_step_deg

        best_angle = 0.0
        best_area = None

        # 기준 자세를 0deg 라고 가정하고, 상대각으로 스캔
        for ang in angles:
            self.rotate_by_deg(ang)
            rospy.sleep(self.scan_wait_sec)

            with self._lock:
                dets = list(self._latest_dets)

            target = self._pick_target_signboard(dets)
            if target is None:
                rospy.logwarn(f"[orientation_align] no signboard detected at ang={ang}")
                continue

            area = self._bbox_area(target)
            rospy.loginfo(f"[orientation_align] ang={ang:.1f} id={int(target.id)} area={area}")

            if best_area is None or area < best_area:
                best_area = area
                best_angle = ang

        # 최적 각도로 이동
        rospy.loginfo(f"[orientation_align] best_angle={best_angle:.1f}, best_area={best_area}")
        self.rotate_by_deg(best_angle)
        rospy.sleep(self.scan_wait_sec)
        self.stop()

        rospy.loginfo("[orientation_align] done")

    def center_align(self, target_id: int):
        """
        (void 타입) 현재 자리에서 target_id 물체가 픽셀 중앙(320)에 오도록 정렬.
        정렬 완료되면 /center_alignment_complished (Int32) 를 1초 publish 후 stop.
        """
        rospy.loginfo(f"[center_align] start: id={target_id}")

        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            with self._lock:
                dets = list(self._latest_dets)

            # target_id 해당 detection 찾기
            target = None
            for d in dets:
                if int(d.id) == int(target_id):
                    target = d
                    break

            if target is None:
                rospy.logwarn(f"[center_align] target id={target_id} not detected")
                self.stop()
                rate.sleep()
                continue

            cu = int(target.center_u)
            err = self.image_center_u - cu  # +면 오른쪽으로 돌려야? (로봇 기준에 맞게 부호는 조정)

            if abs(err) <= self.center_tol_px:
                rospy.loginfo("[center_align] aligned")
                self.stop()
                self._publish_center_done_1sec()
                return

            # pixel error -> deg command (단순 P)
            cmd_deg = self.kp_center * float(err)
            cmd_deg = max(min(cmd_deg, 5.0), -5.0)  # 과도 회전 제한(임의)
            self.rotate_by_deg(cmd_deg)

            rate.sleep()

    def height_align(self, target_id: int, target_h_px: int=10, tol_px: int = 3,
                     step_m: float = 0.01, wait_sec: float = 0.5, max_steps: int = 200):
        """
        (void 타입)
        target_id 물체 bbox height가 target_h_px ± tol_px 안에 들어오도록
        0.01m씩 전/후진하며 height를 반복 체크.

        - height = |y2 - y1|
        - height < target -> 전진 (가까이 가서 bbox 크게)
        - height > target -> 후진 (멀어져 bbox 작게)
        """
        rospy.loginfo(f"[height_align] start: id={target_id}, target_h_px={target_h_px}, tol_px={tol_px}")

        for i in range(int(max_steps)):
            if rospy.is_shutdown():
                return

            # 최신 detection에서 target 찾기
            with self._lock:
                dets = list(self._latest_dets)

            target = None
            for d in dets:
                if int(d.id) == int(target_id):
                    target = d
                    break

            if target is None:
                rospy.logwarn(f"[height_align] step={i}: target id={target_id} not detected -> stop")
                self.stop()
                rospy.sleep(wait_sec)
                continue

            h = abs(int(target.y2) - int(target.y1))
            err = int(target_h_px) - int(h)

            rospy.loginfo(f"[height_align] step={i}: h={h}, err={err}")

            # 목표 범위 안이면 종료
            if abs(err) <= int(tol_px):
                rospy.loginfo("[height_align] aligned")
                self.stop()
                return

            # 단순 스텝 이동
            if err > 0:
                # height가 작다 -> 더 가까이(전진)
                self.fmove_by_dis_m(step_m)
            else:
                # height가 크다 -> 더 멀리(후진)
                self.rmove_by_dis_m(step_m)

            rospy.sleep(wait_sec)

        rospy.logwarn("[height_align] reached max_steps -> stop")
        self.stop()


    def _publish_center_done_1sec(self):
        """
        /center_alignment_complished 를 1초만 publish하고 끔
        """
        msg = Int32()
        msg.data = 1

        end_t = rospy.Time.now() + rospy.Duration(1.0)
        r = rospy.Rate(20)
        while not rospy.is_shutdown() and rospy.Time.now() < end_t:
            self.center_done_pub.publish(msg)
            r.sleep()
        msg.data = 0
        self.center_done_pub.publish(msg)

        # 끄는 동작: publish 중단(그냥 함수 종료로 끝)
        rospy.loginfo("[center_align] published /center_alignment_complished for 1s")


def main():
    rospy.init_node("signboard_controller_py")
    node = SignboardController()
    rospy.loginfo("signboard_controller_py is up.")
    rospy.spin()


if __name__ == "__main__":
    main()

